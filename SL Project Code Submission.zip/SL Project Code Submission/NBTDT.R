library(caret)
library(tree)

##Code written by Marc Vazquez

##Decision Tree implementation on only full valued observations of the Adult Dataset

adult = read.csv("C:/Users/Marc/Desktop/SLproject/preprocessed_data.csv")

adult = adult[2:14]

per_train = .7
trainindex <- createDataPartition(y = adult$income_class,p = per_train, list = FALSE)

##Data is partitioned for CV, but this went unused in final trials

adult_train <- adult[ trainindex,]
adult_test <- adult[-trainindex,]

##Labels are factorized

adult_train$income_class <- factor(adult_train$income_class)
adult_test$income_class <- factor(adult_test$income_class)

##Decision Tree

atree <- tree(income_class~.,data=adult_train)
summary(atree)

plot(atree)
text(atree)

apredict <- predict(atree,adult_test,type="class")
treecm <-table(adult_test$income_class,apredict)
acc_tree <- 1- ((treecm[2]+treecm[3])/(sum(treecm[1:4])))

##Pruning the Tree 
prune <- prune.tree(atree,best=5)
plot(prune)
text(prune)

sprune = summary(prune)

pprune <- predict(prune,adult_test,type="class")
prunecm <- table(adult_test$income_class,pprune)

acc_pruned <- 1- ((prunecm[2]+prunecm[3])/(sum(prunecm[1:4])))