---
title: "Stats Final"
author: "Sunjana Ramana Chintala"
date: "12/18/2021"
output: html_document
---

```{r setup, include=FALSE}
knitr::opts_chunk$set(echo = TRUE)
```



```{r}

library(tidyverse)
library(ISLR)
library(mice)
library(FactoMineR)
library(mlbench)
library(caret)

```


```{r}

setwd(dir="C:/Users/sunja/OneDrive/Documents/Statlearning/Stats_final_project/final")
adult_X = read.table("C:/Users/sunja/OneDrive/Documents/Statlearning/Stats_final_project/final/adult.txt.data", sep=",", header=F, fill=FALSE, strip.white=T)
colnames(adult_X) = c("age", "workclass", "fnlwgt", "education", "education_num", 
                      "marital_status", "occupation", "relationship", "race", "sex",
                      "capital_gain", "capital_loss", "hours_per_week", "native_country", 
                      "income_class")

```


```{r}
str(adult_X)
head(adult_X,10)

dim(adult_X)

```



```{r}



adult_X[["fnlwgt"]]=NULL

adult_X[["education"]]=NULL

str(adult_X)
```




```{r fig.width=20, fig.height=8}


library(ggplot2)
library(grid)
library(gridExtra)
#install.packages('patchwork')
library(patchwork)

par(mfrow = c(3,3))



    
#Workclass
p1 = ggplot(adult_X) +
       aes(x = workclass) +
       geom_bar(fill = "#4682B4") +
       labs(x = "CATEGORIES", y = "COUNT", 
       title = "Workclass Barplot") +
       coord_flip() +
       ggthemes::theme_gdocs()

#Marital Status
p2 = ggplot(adult_X) +
       aes(x = marital_status) +
       geom_bar(fill = "#5F775F") +
       labs(x = "CATEGORIES", y = "COUNT", 
       title = "Marital Status Barplot") +
       coord_flip() +
       ggthemes::theme_gdocs()

#Occupation
p3_old = ggplot(adult_X) +
       aes(x = occupation) +
       geom_bar(fill = "#87643B") +
       labs(x = "CATEGORIES", y = "COUNT", 
       title = "Occupation Barplot") +
       coord_flip() +
       ggthemes::theme_gdocs()

#Relationship
p4 = ggplot(adult_X) +
       aes(x = relationship) +
       geom_bar(fill = "#4E1D59") +
       labs(x = "CATEGORIES", y = "COUNT", 
       title = "Relationship Barplot") +
       coord_flip() +
       ggthemes::theme_gdocs()

#Race
p5 = ggplot(adult_X) +
       aes(x = race) +
       geom_bar(fill = "#79301C") +
       labs(x = "CATEGORIES", y = "COUNT", title = "Race Barplot") +
       coord_flip() +
       ggthemes::theme_gdocs()

#Sex
p6 = ggplot(adult_X) +
       aes(x = sex) +
       geom_bar(fill = "#D47171") +
       labs(x = "CATEGORIES", y = "COUNT", title = "Sex Barplot") +
       coord_flip() +
       ggthemes::theme_gdocs()

#Native Country
p7 = ggplot(adult_X) +
       aes(x = native_country) +
       geom_bar(fill = "#959B18") +
       labs(x = "CATEGORIES", y = "COUNT", 
       title = "Native Country") +
       coord_flip() +
       ggthemes::theme_gdocs()

#Income Class
p8 = ggplot(adult_X) +
       aes(x = income_class) +
       geom_bar(fill = "#926D9B") +
       labs(x = "CATEGORIES", y = "COUNT", 
       title = "Income Class") +
       coord_flip() +
       ggthemes::theme_gdocs()


p1 + p2  + p4 + p5 + p6 +  p8 + plot_layout(nrow=3)
 



```



```{r}
p3 


```


```{r}
p7 


```

```{r}
is.na(adult_X) = adult_X=='?'
is.na(adult_X) = adult_X==' ?'
adult_X = na.omit(adult_X)


p3 = ggplot(adult_X) +
       aes(x = occupation) +
       geom_bar(fill = "#87643B") +
       labs(x = "CATEGORIES", y = "COUNT", 
       title = "Occupation Barplot Cleaned") +
       coord_flip() +
       ggthemes::theme_gdocs()



p3_old +p3

```





```{r}

adult_X$occupation = gsub("^Adm-clerical","Admin",adult_X$occupation)
adult_X$occupation = gsub("^Armed-Forces","Military",adult_X$occupation)
adult_X$occupation = gsub("^Craft-repair","Blue-Collar",adult_X$occupation)
adult_X$occupation = gsub("^Exec-managerial","White-Collar",adult_X$occupation)
adult_X$occupation = gsub("^Farming-fishing","Blue-Collar",adult_X$occupation)
adult_X$occupation = gsub("^Handlers-cleaners","Blue-Collar",adult_X$occupation)
adult_X$occupation = gsub("^Machine-op-inspct","Blue-Collar",adult_X$occupation)
adult_X$occupation = gsub("^Other-service","Service",adult_X$occupation)
adult_X$occupation = gsub("^Priv-house-serv","Service",adult_X$occupation)
adult_X$occupation = gsub("^Prof-specialty","Professional",adult_X$occupation)
adult_X$occupation = gsub("^Protective-serv","Other-Occupations",adult_X$occupation)
adult_X$occupation = gsub("^Sales","Sales",adult_X$occupation)
adult_X$occupation = gsub("^Tech-support","Other-Occupations",adult_X$occupation)
adult_X$occupation = gsub("^Transport-moving","Blue-Collar",adult_X$occupation)



```








```{r}

adult_X$marital_status[adult_X$marital_status=="Never-married"] = "Never-Married"
adult_X$marital_status[adult_X$marital_status=="Married-AF-spouse"] = "Married"
adult_X$marital_status[adult_X$marital_status=="Married-civ-spouse"] = "Married"
adult_X$marital_status[adult_X$marital_status=="Married-spouse-absent"] = "Not-Married"
adult_X$marital_status[adult_X$marital_status=="Separated"] = "Not-Married"
adult_X$marital_status[adult_X$marital_status=="Divorced"] = "Not-Married"
adult_X$marital_status[adult_X$marital_status=="Widowed"] = "Widowed"


p2_mod = ggplot(adult_X) +
       aes(x = marital_status) +
       geom_bar(fill = "#5F775F") +
       labs(x = "CATEGORIES", y = "COUNT", 
       title = "Marital Status Barplot Modified") +
       coord_flip() +
       ggthemes::theme_gdocs()

p2 + p2_mod



```



```{r}


adult_X$workclass = gsub("^Federal-gov","Federal-Govt",adult_X$workclass)
adult_X$workclass = gsub("^Local-gov","Other-Govt",adult_X$workclass)
adult_X$workclass = gsub("^State-gov","Other-Govt",adult_X$workclass)
adult_X$workclass = gsub("^Private","Private",adult_X$workclass)
adult_X$workclass = gsub("^Self-emp-inc","Self-Employed",adult_X$workclass)
adult_X$workclass = gsub("^Self-emp-not-inc","Self-Employed",adult_X$workclass)
adult_X$workclass = gsub("^Without-pay","Not-Working",adult_X$workclass)
adult_X$workclass = gsub("^Never-worked","Not-Working",adult_X$workclass)




p1_new = ggplot(adult_X) +
       aes(x = workclass) +
       geom_bar(fill = "#4682B4") +
       labs(x = "CATEGORIES", y = "COUNT", 
       title = "Workclass Barplot Modified") +
       coord_flip() +
       ggthemes::theme_gdocs()

p1+ p1_new



```




```{r}

adult_X$race[adult_X$race=="White"] = "White"
adult_X$race[adult_X$race=="Black"] = "Black"
adult_X$race[adult_X$race=="Amer-Indian-Eskimo"] = "Amer-Indian"
adult_X$race[adult_X$race=="Asian-Pac-Islander"] = "Asian"
adult_X$race[adult_X$race=="Other"] = "Other"


p5_modified = ggplot(adult_X) +
       aes(x = race) +
       geom_bar(fill = "#79301C") +
       labs(x = "CATEGORIES", y = "COUNT", title = "Race Modified") +
       coord_flip() +
       ggthemes::theme_gdocs()

p5 + p5_modified



```






```{r}

adult_X$native_country[adult_X$native_country=="Cambodia"] = "South East Asia"
adult_X$native_country[adult_X$native_country=="Canada"] = "British-Commonwealth"     
adult_X$native_country[adult_X$native_country=="China"] = "China"        
adult_X$native_country[adult_X$native_country=="Columbia"] = "South-America"     
adult_X$native_country[adult_X$native_country=="Cuba"] = "Other"         
adult_X$native_country[adult_X$native_country=="Dominican-Republic"] = "Latin-America"
adult_X$native_country[adult_X$native_country=="Ecuador"] = "South-America"      
adult_X$native_country[adult_X$native_country=="El-Salvador"] = "South-America"  
adult_X$native_country[adult_X$native_country=="England"] = "British-Commonwealth"
adult_X$native_country[adult_X$native_country=="France"] = "Euro_1"
adult_X$native_country[adult_X$native_country=="Germany"] = "Euro_1"
adult_X$native_country[adult_X$native_country=="Greece"] = "Euro_2"
adult_X$native_country[adult_X$native_country=="Guatemala"] = "Latin-America"
adult_X$native_country[adult_X$native_country=="Haiti"] = "Latin-America"
adult_X$native_country[adult_X$native_country=="Holand-Netherlands"] = "Euro_1"
adult_X$native_country[adult_X$native_country=="Honduras"] = "Latin-America"
adult_X$native_country[adult_X$native_country=="Hong"] = "China"
adult_X$native_country[adult_X$native_country=="Hungary"] = "Euro_2"
adult_X$native_country[adult_X$native_country=="India"] = "British-Commonwealth"
adult_X$native_country[adult_X$native_country=="Iran"] = "Other"
adult_X$native_country[adult_X$native_country=="Ireland"] = "British- Commonwealth"
adult_X$native_country[adult_X$native_country=="Italy"] = "Euro_1"
adult_X$native_country[adult_X$native_country=="Jamaica"] = "Latin-America"
adult_X$native_country[adult_X$native_country=="Japan"] = "Other"
adult_X$native_country[adult_X$native_country=="Laos"] = "South East-Asia"
adult_X$native_country[adult_X$native_country=="Mexico"] = "Latin-America"
adult_X$native_country[adult_X$native_country=="Nicaragua"] = "Latin-America"
adult_X$native_country[adult_X$native_country=="Outlying-US(Guam-USVI-etc)"] = "Latin-America"
adult_X$native_country[adult_X$native_country=="Peru"] = "South-America"
adult_X$native_country[adult_X$native_country=="Philippines"] = "SE-Asia"
adult_X$native_country[adult_X$native_country=="Poland"] = "Euro_2"
adult_X$native_country[adult_X$native_country=="Portugal"] = "Euro_2"
adult_X$native_country[adult_X$native_country=="Puerto-Rico"] = "Latin-America"
adult_X$native_country[adult_X$native_country=="Scotland"] = "British-Commonwealth"
adult_X$native_country[adult_X$native_country=="South"] = "Euro_2"
adult_X$native_country[adult_X$native_country=="Taiwan"] = "China"
adult_X$native_country[adult_X$native_country=="Thailand"] = "SE-Asia"
adult_X$native_country[adult_X$native_country=="Trinadad&amp;Tobago"] = "Latin-America"
adult_X$native_country[adult_X$native_country=="United-States"] = "United-States"
adult_X$native_country[adult_X$native_country=="Vietnam"] = "SE-Asia"
adult_X$native_country[adult_X$native_country=="Yugoslavia"] = "Euro_2"




```


#Preprocessing of Continous Variables



```{r}


library(ggplot2)

c1 <- ggplot(adult_X) +
 aes(x = income_class, y = age, fill = income_class) +
 geom_boxplot(shape = "circle") +
 scale_fill_hue(direction = 1) +
 labs(x = "Income", y = "Age", title = "Age Box Plot") +
 theme_gray() +
 theme(legend.position = "top", plot.title = element_text(size = 15L, face = "bold", hjust = 0.5))

c2 <- ggplot(adult_X) +
 aes(x = income_class, y = education_num, fill = income_class) +
 geom_boxplot(shape = "circle") +
 scale_fill_hue(direction = 1) +
 labs(x = "Income", y = "Education_num", title = "Education Box Plot") +
 theme_gray() +
 theme(legend.position = "top", plot.title = element_text(size = 15L, face = "bold", 
 hjust = 0.5))

c3 <- ggplot(adult_X) +
 aes(x = income_class, y = capital_gain, fill = income_class) +
 geom_boxplot(shape = "circle") +
 scale_fill_hue(direction = 1) +
 labs(x = "Income", y = "Capital_Gain", title = "Capital_Gain Box Plot") +
 theme_gray() +
 theme(legend.position = "top", plot.title = element_text(size = 15L, face = "bold", 
 hjust = 0.5))

c4 <- ggplot(adult_X) +
 aes(x = income_class, y = capital_loss, fill = income_class) +
 geom_boxplot(shape = "circle") +
 scale_fill_hue(direction = 1) +
 labs(x = "Income", y = "Capital_Loss", title = "Capital_Loss Box Plot") +
 theme_gray() +
 theme(legend.position = "top", plot.title = element_text(size = 15L, face = "bold", 
 hjust = 0.5))

c5 <- ggplot(adult_X) +
 aes(x = income_class, y = hours_per_week, fill = income_class) +
 geom_boxplot(shape = "circle") +
 scale_fill_hue(direction = 1) +
 labs(x = "Income", y = "Hours_Per_Week", title = "Hours_Per_Week Box Plot") +
 theme_gray() +
 theme(legend.position = "top", plot.title = element_text(size = 15L, face = "bold", 
 hjust = 0.5))

c1+c2+c3+c4+c5


```
#Principal Component Analysis

```{r}


adult_X_caploss = adult_X[adult_X$capital_loss!=0,]
adult_X_capgain = adult_X[adult_X$capital_gain!=0,]
adult_X = rbind(adult_X_caploss, adult_X_capgain)

```





```{r}

c3_modified <- ggplot(adult_X) +
 aes(x = income_class, y = capital_gain, fill = income_class) +
 geom_boxplot(shape = "circle") +
 scale_fill_hue(direction = 1) +
 labs(x = "Income", y = "Capital_Gain", title = "Capital_Gain Modified") +
 theme_gray() +
 theme(legend.position = "top", plot.title = element_text(size = 15L, face = "bold", 
 hjust = 0.5))

c4_modified <- ggplot(adult_X) +
 aes(x = income_class, y = capital_loss, fill = income_class) +
 geom_boxplot(shape = "circle") +
 scale_fill_hue(direction = 1) +
 labs(x = "Income", y = "Capital_Loss", title = "Capital_Loss Modified") +
 theme_gray() +
 theme(legend.position = "top", plot.title = element_text(size = 15L, face = "bold", 
 hjust = 0.5))

c3+c3_modified +c4+c4_modified

```






```{r}

max <- quantile(adult_X$capital_gain,0.75, na.rm=TRUE) + (IQR(adult_X$capital_gain, na.rm=TRUE) * 3)
adult_X <- adult_X[adult_X$capital_gain < as.numeric(max),]

c3_final <- ggplot(adult_X) +
 aes(x = income_class, y = capital_gain, fill = income_class) +
 geom_boxplot(shape = "circle") +
 scale_fill_hue(direction = 1) +
 labs(x = "Income", y = "Capital_Gain", title = "Capital_Gain Final") +
 theme_gray() +
 theme(legend.position = "top", plot.title = element_text(size = 15L, face = "bold", 
 hjust = 0.5))

c4_final <- ggplot(adult_X) +
 aes(x = income_class, y = capital_loss, fill = income_class) +
 geom_boxplot(shape = "circle") +
 scale_fill_hue(direction = 1) +
 labs(x = "Income", y = "Capital_Loss", title = "Capital_Loss Final") +
 theme_gray() +
 theme(legend.position = "top", plot.title = element_text(size = 15L, face = "bold", 
 hjust = 0.5))


c3_modified + c3_final + c4_modified + c4_final
```


```{r}


X.c <- adult_X
adult_X$workclass = as.character(adult_X$workclass)
adult_X$occupation = as.character(adult_X$occupation)
adult_X$native_country = as.character(adult_X$native_country)
adult_X$race = as.character(adult_X$race)
adult_X$marital_status = as.character(adult_X$marital_status)
summary(adult_X[c(2,5,6)])

#install.packages('mice')


```


```{r}

library(ggfortify)

# <- prcomp(X.C , scale. = TRUE, colour = 'income_class')


#autoplot(pca)





```




```{r}

library(mice)

X_C_mice <- mice(X.C)
X_C_complete = complete(X_C_mice)
summary(X_C_complete)

```



```{r}

df <- X_C_complete[, c("age", "education_num", "capital_gain", "capital_loss", "hours_per_week")]


pca <- prcomp(df, scale. = TRUE)

pca1 <- autoplot(pca,data = X.C.complete, colour = 'income_class',loadings = TRUE, loadings.colour = 'black', loadings.size = 6,
         )

pca2  <- autoplot(pca,data = X.C.complete, colour = 'income_class')




pca3 <- autoplot(pca, data = X.C.complete, colour = 'income_class', shape = FALSE, label.size = 1,loadings = TRUE, loadings.colour = 'black', loadings.size = 6,
         loadings.label = TRUE, loadings.label.size = 4 )



(plot_spacer() + pca3 + plot_spacer())/(pca1 + plot_spacer() + pca2)


```




```{r}
((pca2 / pca1 + plot_layout(guides = 'auto')) | pca3) + plot_layout(guides = 'collect')



```

```{r}

library(FactoMineR)

df2 <- X_C_complete[, c("workclass", "marital_status", "relationship", "race", "occupation", 'sex','native_country','income_class')]


tea.mca <- MCA(df2, graph=FALSE)
#autoplot(tea.mca)

df3 <- fortify(df2, data = X.C.complete, quali.sup = TRUE)
df3




```





```{r}

MCA = MCA(X = X_C_complete[,c(2,4,5,6,7,8,12,13)], quali.sup = 8)

```





