install.packages("rJava")
install.packages("RWekajars")
install.packages("RWeka")
library(caret)
library("rJava")
library("RWekajars")
library("RWeka")

WPM("refresh-cache")
WPM("package-info", "repository", "naiveBayesTree")
WPM("install-package", "naiveBayesTree")

##Code written by Marc Vazquez

##Naive Bayes Tree implementation on the Adult Dataset

adult = read.csv("C:/Users/Marc/Desktop/SLproject/adult_csv.csv")

per_train = .7
trainindex <- createDataPartition(y = adult$class,p = per_train, list = FALSE)

adult_train <- adult[ trainindex,]
adult_test <- adult[-trainindex,]

adult_train <- cbind(adult_train[,1:2],adult_train[,4],adult_train[,6:15])
adult_test <- cbind(adult_test[,1:2],adult_test[,4],adult_test[,6:15])

adult_train$class <- factor(adult_train$class)
adult_test$class <- factor(adult_test$class)

adult_train_dummy <- predict(dummyVars(" ~ .", data=data.frame(adult_train)),newdata=data.frame(adult_train))
adult_test_dummy <- predict(dummyVars(" ~ .", data=data.frame(adult_test)),newdata=data.frame(adult_test))

colnames(adult_test_dummy)<-colnames(adult_train_dummy)

##Utilizing same java based library utilized in the main paper

NBTree <- make_Weka_classifier("weka/classifiers/trees/NBTree")
NBT <- NBTree(adult_train$class~ ., data=data.frame(adult_train_dummy[,1:105]))

NBT_test <- predict(NBT,data.frame(adult_test_dummy[,1:105]))
NBT_con <- confusionMatrix(data=NBT_test,reference=adult_test$class)
NBT_acc <- NBT_con[["overall"]][["Accuracy"]]
