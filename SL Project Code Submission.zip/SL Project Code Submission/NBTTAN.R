library(caret)
library(naivebayes)
library(tree)
library(bnlearn)

##Code written by Marc Vazquez

##Tree Augmented Naive Bayes implementation on Adult dataset

adult = read.csv("C:/Users/Marc/Desktop/SLproject/adult_csv.csv")

per_train = .7
trainindex <- createDataPartition(y = adult$class,p = per_train, list = FALSE)

adult_train <- adult[ trainindex,]
adult_test <- adult[-trainindex,]

adult_train <- cbind(adult_train[,1:2],adult_train[,4],adult_train[,6:15])
adult_test <- cbind(adult_test[,1:2],adult_test[,4],adult_test[,6:15])

adult_train_dummy <- predict(dummyVars(" ~ .", data=data.frame(adult_train)),newdata=data.frame(adult_train))
adult_test_dummy <- predict(dummyVars(" ~ .", data=data.frame(adult_test)),newdata=data.frame(adult_test))

adult_train <- data.frame(adult_train)
adult_test <- data.frame(adult_test)

colnames(adult_train)[3] <- "education"
colnames(adult_test)[3] <- "education"

for (k in 1:length(adult_train))
{
  adult_train[,k] <- factor(as.character(adult_train[,k]))
  adult_test[,k] <- factor(as.character(adult_test[,k]))
}

tan <- tree.bayes(adult_train[,1:13],"class")

tan_fit <- bn.fit(tan,adult_train,method="bayes")

tan_test <- predict(tan_fit,adult_test)

tan_con <- confusionMatrix(data=tan_test,reference=(adult_test$class))

acc_tan <- tan_con[["overall"]][["Accuracy"]]
