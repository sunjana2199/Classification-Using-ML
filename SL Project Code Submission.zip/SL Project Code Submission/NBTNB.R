library(caret)
library(naivebayes)
library(tree)

##Code written by Marc Vazquez

##Naive Bayes Classifier implementation for Adult Dataset

adult = read.csv("C:/Users/Marc/Desktop/SLproject/adult_csv.csv")

per_train = .7
trainindex <- createDataPartition(y = adult$class,p = per_train, list = FALSE)

adult_train <- adult[ trainindex,]
adult_test <- adult[-trainindex,]

##Omit redundant columns, create dummy variables for each categorical

adult_train <- cbind(adult_train[,1:2],adult_train[,4],adult_train[,6:15])
adult_test <- cbind(adult_test[,1:2],adult_test[,4],adult_test[,6:15])

adult_train_dummy <- predict(dummyVars(" ~ .", data=data.frame(adult_train)),newdata=data.frame(adult_train))
adult_test_dummy <- predict(dummyVars(" ~ .", data=data.frame(adult_test)),newdata=data.frame(adult_test))

nb_train <- naive_bayes(data.frame(adult_train_dummy),as.logical(adult_train_dummy[,"class>50K"]))

nb_test <- predict(nb_train,data.frame(adult_test_dummy))

nb_con <- confusionMatrix(data=nb_test,reference=factor(as.logical(adult_test_dummy[,"class>50K"])))

acc_nb <- nb_con[["overall"]][["Accuracy"]]
