library(caret)
library(tree)

##Code written by Marc Vazquez

##Decision Tree implementation on full Adult Dataset

adult = read.csv("C:/Users/Marc/Desktop/SLproject/adult_csv.csv")

per_train = .7
trainindex <- createDataPartition(y = adult$class,p = per_train, list = FALSE)

##Data is partitioned for CV, but this went unused in final trials

adult_train <- adult[ trainindex,]
adult_test <- adult[-trainindex,]

##Labels are factorized

adult_train <- cbind(adult_train[,1:2],adult_train[,4],adult_train[,6:15])
adult_test <- cbind(adult_test[,1:2],adult_test[,4],adult_test[,6:15])

adult_train$class <- factor(adult_train$class)
adult_test$class <- factor(adult_test$class)

adult_train_dummy <- predict(dummyVars(" ~ .", data=data.frame(adult_train)),newdata=data.frame(adult_train))
adult_test_dummy <- predict(dummyVars(" ~ .", data=data.frame(adult_test)),newdata=data.frame(adult_test))

colnames(adult_test_dummy)<-colnames(adult_train_dummy)

##Decision Tree

atree <- tree(adult_train$class~.,data=data.frame(adult_train_dummy)[,1:105])
summary(atree)
plot(atree)
text(atree)



apredict <- predict(atree,data.frame(adult_test_dummy[,1:105]),type="class")
treecm <-table(adult_test$class,apredict)
tree_acc <- 1- ((treecm[2]+treecm[3])/(sum(treecm[1:4])))

##Pruning the Tree

prune <- prune.tree(atree,best=5)
plot(prune)
text(prune)

sprune = summary(prune)

pprune <- predict(prune,data.frame(adult_test_dummy)[,1:107],type="class")
prunecm <- table(adult_test$class,pprune)

pruned_acc <- 1- ((prunecm[2]+prunecm[3])/(sum(prunecm[1:4])))