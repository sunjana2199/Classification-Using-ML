library(tidyverse)
library(ISLR)
#install.packages("mice")
library(mice)
#install.packages("FactoMineR")
library(FactoMineR)
install.packages("mlbench")
library(mlbench)
#install.packages("caret")
library(caret)
setwd(dir='C:/Users/manis/Desktop/SLProject')
X.adult = read.table("C:/Users/manis/Desktop/SLProject/New folder/adult.txt.data", sep=",", header=F, fill=FALSE, strip.white=T)
colnames(X.adult) = c("age", "workclass", "fnlwgt", "education", "education_num", 
                      "marital_status", "occupation", "relationship", "race", "sex",
                      "capital_gain", "capital_loss", "hours_per_week", "native_country", 
                      "income_class")
head(X.adult,10)
par(mfrow = c(1,3))
t0<-table(X.adult$workclass)
pie(t0,col = hcl.colors(length(t0), "BluYl"))
t1<-table(X.adult$marital_status)
pie(t1,col = hcl.colors(length(t1), "BluYl"))
t2<-table(X.adult$occupation)
pie(t2,col = hcl.colors(length(t2), "BluYl"))

X.adult[["fnlwgt"]]=NULL
X.adult[["education"]]=NULL

#plot(X.adult[1:3000,])

par(mfrow = c(1,6))
boxplot(X.adult$age, main="age")
boxplot(X.adult$capital_gain, main="capital_gain")
boxplot(X.adult$capital_loss, main="capital_loss")
boxplot(X.adult$hours_per_week, main="hours_per_week")
boxplot(X.adult$education_num, main="education_num")
boxplot(X.adult$fnlwgt, main="fnlwgt")

par(mfrow = c(2,4))
barplot(prop.table(table(X.adult$workclass)), main = "workclass")
barplot(prop.table(table(X.adult$marital_status)), main = "marital_status")
#barplot(prop.table(table(X.adult$education)), main = "education")
barplot(prop.table(table(X.adult$occupation)), main = "occupation")
barplot(prop.table(table(X.adult$relationship)), main = "relationship")
barplot(prop.table(table(X.adult$race)), main = "race")
barplot(prop.table(table(X.adult$sex)), main = "sex")
barplot(prop.table(table(X.adult$native_country)), main = "native_country")
barplot(prop.table(table(X.adult$income_class)), main = "income_class")

X.adult.caploss= X.adult[X.adult$capital_loss!=0,]
X.adult.capgain= X.adult[X.adult$capital_gain!=0,]
X.adult = rbind(X.adult.caploss, X.adult.capgain)

par(mfrow = c(1,2))
boxplot(X.adult$capital_gain, main="boxplot capital_gain")
boxplot(X.adult$capital_loss, main="boxplot capital_loss")

max <- quantile(X.adult$capital_gain,0.75, na.rm=TRUE) + (IQR(X.adult$capital_gain, na.rm=TRUE) * 3)
X.adult <- X.adult[X.adult$capital_gain < as.numeric(max),]

par(mfrow = c(1,2))
boxplot(X.adult$capital_gain, main="boxplot capital_gain")
boxplot(X.adult$capital_loss, main="boxplot capital_loss")

X.adult$workclass = as.character(X.adult$workclass)
X.adult$occupation = as.character(X.adult$occupation)
X.adult$native_country = as.character(X.adult$native_country)
X.adult$race = as.character(X.adult$race)
X.adult$marital_status = as.character(X.adult$marital_status)

X.adult$marital_status[X.adult$marital_status=="Never-married"] = "Never-Married"
X.adult$marital_status[X.adult$marital_status=="Married-AF-spouse"] = "Married"
X.adult$marital_status[X.adult$marital_status=="Married-civ-spouse"] = "Married"
X.adult$marital_status[X.adult$marital_status=="Married-spouse-absent"] = "Not-Married"
X.adult$marital_status[X.adult$marital_status=="Separated"] = "Not-Married"
X.adult$marital_status[X.adult$marital_status=="Divorced"] = "Not-Married"
X.adult$marital_status[X.adult$marital_status=="Widowed"] = "Widowed"


X.adult$workclass = gsub("^Federal-gov","Federal-Govt",X.adult$workclass)
X.adult$workclass = gsub("^Local-gov","Other-Govt",X.adult$workclass)
X.adult$workclass = gsub("^State-gov","Other-Govt",X.adult$workclass)
X.adult$workclass = gsub("^Private","Private",X.adult$workclass)
X.adult$workclass = gsub("^Self-emp-inc","Self-Employed",X.adult$workclass)
X.adult$workclass = gsub("^Self-emp-not-inc","Self-Employed",X.adult$workclass)
X.adult$workclass = gsub("^Without-pay","Not-Working",X.adult$workclass)
X.adult$workclass = gsub("^Never-worked","Not-Working",X.adult$workclass)

X.adult$occupation = gsub("^Adm-clerical","Admin",X.adult$occupation)
X.adult$occupation = gsub("^Armed-Forces","Military",X.adult$occupation)
X.adult$occupation = gsub("^Craft-repair","Blue-Collar",X.adult$occupation)
X.adult$occupation = gsub("^Exec-managerial","White-Collar",X.adult$occupation)
X.adult$occupation = gsub("^Farming-fishing","Blue-Collar",X.adult$occupation)
X.adult$occupation = gsub("^Handlers-cleaners","Blue-Collar",X.adult$occupation)
X.adult$occupation = gsub("^Machine-op-inspct","Blue-Collar",X.adult$occupation)
X.adult$occupation = gsub("^Other-service","Service",X.adult$occupation)
X.adult$occupation = gsub("^Priv-house-serv","Service",X.adult$occupation)
X.adult$occupation = gsub("^Prof-specialty","Professional",X.adult$occupation)
X.adult$occupation = gsub("^Protective-serv","Other-Occupations",X.adult$occupation)
X.adult$occupation = gsub("^Sales","Sales",X.adult$occupation)
X.adult$occupation = gsub("^Tech-support","Other-Occupations",X.adult$occupation)
X.adult$occupation = gsub("^Transport-moving","Blue-Collar",X.adult$occupation)

is.na(X.adult) = X.adult=='?'
is.na(X.adult) = X.adult==' ?'
X.adult = na.omit(X.adult)

X.adult$marital_status = factor(X.adult$marital_status)
X.adult$native_country = factor(X.adult$native_country)
X.adult$workclass = factor(X.adult$workclass)
X.adult$occupation = factor(X.adult$occupation)
X.adult$race = factor(X.adult$race)
X.adult$sex = factor(X.adult$sex)
X.adult$relationship = factor(X.adult$relationship)


par(mfrow = c(1,3))
t0<-table(X.adult$workclass)
pie(t0,col = hcl.colors(length(t0), "BluYl"))
t1<-table(X.adult$marital_status)
pie(t1,col = hcl.colors(length(t1), "BluYl"))
t2<-table(X.adult$occupation)
pie(t2,col = hcl.colors(length(t2), "BluYl"))


par(mfrow = c(2,4))
barplot(prop.table(table(X.adult$workclass)), main = "barplot workclass")
barplot(prop.table(table(X.adult$marital_status)), main = "barplot marital_status")
barplot(prop.table(table(X.adult$occupation)), main = "barplot occupation")
barplot(prop.table(table(X.adult$relationship)), main = "barplot relationship")
barplot(prop.table(table(X.adult$race)), main = "barplot race")
barplot(prop.table(table(X.adult$sex)), main = "barplot sex")
barplot(prop.table(table(X.adult$native_country)), main = "barplot native_country")
barplot(prop.table(table(X.adult$income_class)), main = "barplot income_class")



X.adult.mice <- mice(X.adult)
X.adult.complete = complete(X.adult.mice)
summary(X.adult.complete)



PCA = PCA(X = X.adult.complete, quali.sup = c(2,4,5,6,7,8,12,13))
dev.new(width = 550, height = 330, unit = "px")
biplot(PCA$quali.sup$coord[c("<=50K", ">50K"),],PCA$var$coord, xlim = c(-0.6,0.6), ylim = c(-0.6,0.6), main = "biplot of PCA")
abline(h=0,v=0,col="gray")
MCA = MCA(X = X.adult.complete[,c(2,4,5,6,7,8,12,13)], quali.sup = 8)

N = nrow(X.adult.complete)
split = 1:N
size = round(N*3/4)
split.training = sample(x = split, size = size, replace = FALSE)
split.testing = split[-split.training]
X.adult.training = X.adult.complete[split.training,]
X.adult.testing = X.adult.complete[split.testing, ]

# Naive Bayes
library(e1071)
model.naivebayes <- naiveBayes(income_class ~ ., data = X.adult.training)
pred.naivebayes <- predict(model.naivebayes, newdata=X.adult.testing)
(tab.naivebayes <- table(Truth=X.adult.testing$income_class, Preds=pred.naivebayes) )
(error.naivebayes = 1 - sum(tab.naivebayes[row(tab.naivebayes)==col(tab.naivebayes)])/sum(tab.naivebayes))
acc_nb = sum(tab.naivebayes[row(tab.naivebayes)==col(tab.naivebayes)])/sum(tab.naivebayes)
#importance <- varImp(model.naivebayes, scale=FALSE)


class(X.adult.training$income_class)
X.adult.training$income_class = factor(X.adult.training$income_class)
class(X.adult.training$income_class)


library(e1071)

# Fit an SVM with linear kernel
model.svm.l <- svm(income_class ~ ., data = X.adult.training, type="C-classification", kernel="linear")
pred.svm.l <- predict(model.svm.l, X.adult.testing)
(tab.svm.l <- table(Truth=X.adult.testing$income_class, Preds=pred.svm.linear) )
#(error.svm.linear = 1 - sum(tab.svm.linear[row(tab.svm.linear)==col(tab.svm.linear)])/sum(tab.svm.linear))
acc_svm_l = sum(tab.svm.l[row(tab.svm.l)==col(tab.svm.l)])/sum(tab.svm.l)

## Fit an SVM with quadratic kernel 
model.svm.q <- svm(income_class ~ ., data = X.adult.training, type="C-classification", cost=1, kernel="polynomial", degree=2, coef0=1, scale = FALSE)
pred.svm.q <- predict(model.svm.q, X.adult.testing)
(tab.svm.q <- table(Truth=X.adult.testing$income_class, Preds=pred.svm.q) )
#(error.svm.q = 1 - sum(tab.svm.q[row(tab.svm.q)==col(tab.svm.q)])/sum(tab.svm.q))
acc_svm_q = sum(tab.svm.q[row(tab.svm.q)==col(tab.svm.q)])/sum(tab.svm.q)


## Fit an RBF Gaussian kernel 
model.svm.rbf <- svm(income_class ~ ., data = X.adult.training, type="C-classification", cost=1, kernel="radial", scale = FALSE)

pred.svm.rbf <- predict(model.svm.rbf, X.adult.testing)
(tab.svm.rbf <- table(Truth=X.adult.testing$income_class, Preds=pred.svm.rbf) )
#(error.svm.rbf = 1 - sum(tab.svm.rbf[row(tab.svm.rbf)==col(tab.svm.rbf)])/sum(tab.svm.rbf))
acc_svm_rbf = sum(tab.svm.rbf[row(tab.svm.rbf)==col(tab.svm.rbf)])/sum(tab.svm.rbf)


# Random Forest
install.packages("randomForest")
library(randomForest)

(ntrees <- round(10^seq(1,3,by=0.2)))
rf.results <- matrix (rep(0,2*length(ntrees)),nrow=length(ntrees))
colnames (rf.results) <- c("ntrees", "OOB")
rf.results[,"ntrees"] <- ntrees
rf.results[,"OOB"] <- 0
ii <- 1
for (nt in ntrees)
{ 
  print(nt)
  
  model.X.random <- randomForest(income_class ~ ., X.adult.training, ntree=nt, proximity=FALSE)
  # get the OOB
  rf.results[ii,"OOB"] <- model.X.random$err.rate[nt,1]
  
  ii <- ii+1
}
rf.results
plot(rf.results)
lines(rf.results, pch=16)

model.rf <- randomForest(income_class ~ ., X.adult.training, ntree=400, proximity=FALSE)

pred.model.rf = predict(model.rf, X.adult.testing, type = "class")
(tab.model.rf <- table(Truth=X.adult.testing$income_class, Preds=pred.model.rf) )
#(error.model.rf = 1 - sum(tab.model.rf[row(tab.model.rf)==col(tab.model.rf)])/sum(tab.model.rf))
acc_rf = sum(tab.model.rf[row(tab.model.rf)==col(tab.model.rf)])/sum(tab.model.rf)


# Neural Networks
#install.packages("nnet")
library(nnet)
model.nnet <- nnet(income_class ~., data = X.adult.training, size=10, maxit=20000, decay=0.01)
pred.model.nnet = predict(model.nnet, X.adult.testing, type = "class")

(tab.model.nnet <- table(Truth=X.adult.testing$income_class, Preds=pred.model.nnet) )
#(error.model.rbf = 1 - sum(tab.model.nnet[row(tab.model.nnet)==col(tab.model.nnet)])/sum(tab.model.nnet))
acc_nn = sum(tab.model.nnet[row(tab.model.nnet)==col(tab.model.nnet)])/sum(tab.model.nnet)
