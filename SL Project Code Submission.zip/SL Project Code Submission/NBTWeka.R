# install.packages("rJava")
# install.packages("RWekajars")
# install.packages("RWeka")
library(caret)
library("rJava")
library("RWekajars")
library("RWeka")

WPM("refresh-cache")
WPM("package-info", "repository", "naiveBayesTree")
WPM("install-package", "naiveBayesTree")

##Code written by Marc Vazquez

##Naive Bayes Tree implementation on only full valued observations of the Adult Dataset

adult = read.csv("C:/Users/Marc/Desktop/SLproject/preprocessed_data.csv")
adult = adult[2:14]

per_train = .7
trainindex <- createDataPartition(y = adult$income_class,p = per_train, list = FALSE)

adult_train <- adult[ trainindex,]
adult_test <- adult[-trainindex,]

##Weka only accepts character matrices

for (k in c(2,4,5,6,7,8,12,13))
{
  adult_train[,k] <- factor(as.character(adult_train[,k]))
  adult_test[,k] <- factor(as.character(adult_test[,k]))
}

##Utilizing same java based library utilized in the main paper

NBTree <- make_Weka_classifier("weka/classifiers/trees/NBTree")
NBT <- NBTree(income_class~ ., data=adult_train)

NBT_test <- predict(NBT,adult_test)
NBT_con <- confusionMatrix(data=NBT_test,reference=adult_test$income_class)
acc_nbt <- NBT_con[["overall"]][["Accuracy"]]
